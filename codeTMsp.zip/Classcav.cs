﻿using System;
using System.Collections.Generic;

public class ClassCav
{
    public char[,] Plateau { get; set; }
    public List<string> VisitedPositions { get; set; }
    public int Taille { get; set; }
    public int[] DeplacementsCavalierX { get; set; }
    public int[] DeplacementsCavalierY { get; set; }

    public ClassCav(int taille)
    {
        Taille = taille;
        Plateau = new char[Taille, Taille];
        VisitedPositions = new List<string>();
        DeplacementsCavalierX = new int[] { -2, -1, 1, 2, 2, 1, -1, -2 };
        DeplacementsCavalierY = new int[] { 1, 2, 2, 1, -1, -2, -2, -1 };
    }

    public void Titre() 
    {
        string cavaliertitre = @"
    ██╗     ███████╗     ██████╗ █████╗ ██╗   ██╗ █████╗ ██╗     ██╗███████╗██████╗ 
    ██║     ██╔════╝    ██╔════╝██╔══██╗██║   ██║██╔══██╗██║     ██║██╔════╝██╔══██╗
    ██║     █████╗      ██║     ███████║██║   ██║███████║██║     ██║█████╗  ██████╔╝
    ██║     ██╔══╝      ██║     ██╔══██║╚██╗ ██╔╝██╔══██║██║     ██║██╔══╝  ██╔══██╗
    ███████╗███████╗    ╚██████╗██║  ██║ ╚████╔╝ ██║  ██║███████╗██║███████╗██║  ██║
    ╚══════╝╚══════╝     ╚═════╝╚═╝  ╚═╝  ╚═══╝  ╚═╝  ╚═╝╚══════╝╚═╝╚══════╝╚═╝  ╚═╝
                                                                                
";
        Console.WriteLine(cavaliertitre);
    }
    // Fonction pour initialiser le plateau
    public void InitialiserPlateau()
    {
        for (int i = 0; i < Taille; i++)
        {
            for (int j = 0; j < Taille; j++)
            {
                Plateau[i, j] = ' ';
            }
        }
    }

    // Fonction pour afficher le plateau
    public void AfficherPlateau(int cavalierX, int cavalierY)
    {
        Console.Clear();

        // Afficher les lettres de A à D en haut du plateau (ou plus pour d'autres tailles)
        Console.Write("    ");
        for (int i = 0; i < Taille; i++)
        {
            Console.Write("  " + (char)(65 + i) + " ");
        }
        Console.WriteLine();

        for (int i = 0; i < Taille; i++)
        {
            // Affichage des lignes horizontales
            Console.Write("    ");
            for (int j = 0; j < Taille; j++)
            {
                Console.Write("╬═══");
            }
            Console.WriteLine("╣");

            // Affichage des numéros de lignes dans l'ordre décroissant
            Console.Write("  " + (Taille - i) + " ");

            for (int j = 0; j < Taille; j++)
            {
                if (VisitedPositions.Contains($"{(char)(j + 'A')}{Taille - i}"))
                {
                    Console.BackgroundColor = ConsoleColor.Red;
                    Console.Write("║ " + Plateau[i, j] + " ");
                    Console.ResetColor();
                }
                else
                {
                    // Vérification des cases disponibles pour le cavalier
                    bool mouvementValide = false;
                    for (int k = 0; k < 8; k++)
                    {
                        int nouvelleposX = cavalierX + DeplacementsCavalierX[k];
                        int nouvelleposY = cavalierY + DeplacementsCavalierY[k];

                        // Vérifier si la case est un déplacement valide
                        if (i == nouvelleposX && j == nouvelleposY && !VisitedPositions.Contains($"{(char)(j + 'A')}{Taille - i}"))
                        {
                            mouvementValide = true;
                            break;
                        }
                    }

                    // Si un mouvement est valide, colorier la case en bleu
                    if (mouvementValide)
                    {
                        Console.BackgroundColor = ConsoleColor.Blue;
                        Console.Write("║ " + Plateau[i, j] + " ");
                        Console.ResetColor();
                    }
                    else
                    {
                        Console.Write("║ " + Plateau[i, j] + " ");
                    }
                }
            }
            Console.WriteLine("║");
        }

        // Dernière ligne horizontale du quadrillage
        Console.Write("    ");
        for (int j = 0; j < Taille; j++)
        {
            Console.Write("╬═══");
        }
        Console.WriteLine("╣");
    }

    // Fonction pour obtenir une position valide
    public string ObtenirPositionValide()
    {
        while (true)
        {
            string position = Console.ReadLine().ToUpper();

            if (position.Length == 2 && position[0] >= 'A' && position[0] < 'A' + Taille && position[1] >= '1' && position[1] < '1' + Taille)
            {
                return position;
            }
            else
            {
                Console.WriteLine("Position invalide. Entrez une position valide (ex: A1, B3, etc.).");
            }
        }
    }

    // Fonction pour vérifier si le mouvement est valide
    public bool VerifierMouvement(int x, int y, int deplacementX, int deplacementY)
    {
        for (int i = 0; i < 8; i++)
        {
            int nouvelleX = x + DeplacementsCavalierX[i];
            int nouvelleY = y + DeplacementsCavalierY[i];

            if (nouvelleX == deplacementX && nouvelleY == deplacementY)
            {
                return true;
            }
        }
        return false;
    }
}
