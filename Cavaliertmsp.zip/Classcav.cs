﻿using System;
using System.Collections.Generic;

public class Cavalier
{
    public int LastX;
    public int LastY;

    public char[,] Plateau { get; private set; }
    public List<string> VisitedPositions { get; private set; }
    public int Taille { get; private set; }
    public int[] DeplacementsCavalierX { get; private set; }
    public int[] DeplacementsCavalierY { get; private set; }

    public Cavalier(int taille = 8)
    {
        Taille = taille;
        Plateau = new char[Taille, Taille];
        VisitedPositions = new List<string>();
        DeplacementsCavalierX = new int[] { -2, -1, 1, 2, 2, 1, -1, -2 };
        DeplacementsCavalierY = new int[] { 1, 2, 2, 1, -1, -2, -2, -1 };
        InitialiserPlateau();
    }

    public void Titre()
    {
        string cavaliertitre = @"
    ██╗     ███████╗     ██████╗ █████╗ ██╗   ██╗ █████╗ ██╗     ██╗███████╗██████╗ 
    ██║     ██╔════╝    ██╔════╝██╔══██╗██║   ██║██╔══██╗██║     ██║██╔════╝██╔══██╗
    ██║     █████╗      ██║     ███████║██║   ██║███████║██║     ██║█████╗  ██████╔╝
    ██║     ██╔══╝      ██║     ██╔══██║╚██╗ ██╔╝██╔══██║██║     ██║██╔══╝  ██╔══██╗
    ███████╗███████╗    ╚██████╗██║  ██║ ╚████╔╝ ██║  ██║███████╗██║███████╗██║  ██║
    ╚══════╝╚══════╝     ╚═════╝╚═╝  ╚═╝  ╚═══╝  ╚═╝  ╚═╝╚══════╝╚═╝╚══════╝╚═╝  ╚═╝
                                                                                
";
        Console.WriteLine(cavaliertitre);
    }
    public void niveau1()
    {
        string cavalierniveau1 = @"
███╗   ██╗██╗██╗   ██╗███████╗ █████╗ ██╗   ██╗     ██╗
████╗  ██║██║██║   ██║██╔════╝██╔══██╗██║   ██║    ███║
██╔██╗ ██║██║██║   ██║█████╗  ███████║██║   ██║    ╚██║
██║╚██╗██║██║╚██╗ ██╔╝██╔══╝  ██╔══██║██║   ██║     ██║
██║ ╚████║██║ ╚████╔╝ ███████╗██║  ██║╚██████╔╝     ██║
╚═╝  ╚═══╝╚═╝  ╚═══╝  ╚══════╝╚═╝  ╚═╝ ╚═════╝      ╚═╝
                                                                                              
";
        Console.WriteLine(cavalierniveau1);
    }
    public void niveau2()
    {
        string cavalierniveau2 = @"
███╗   ██╗██╗██╗   ██╗███████╗ █████╗ ██╗   ██╗    ██████╗ 
████╗  ██║██║██║   ██║██╔════╝██╔══██╗██║   ██║    ╚════██╗
██╔██╗ ██║██║██║   ██║█████╗  ███████║██║   ██║     █████╔╝
██║╚██╗██║██║╚██╗ ██╔╝██╔══╝  ██╔══██║██║   ██║    ██╔═══╝ 
██║ ╚████║██║ ╚████╔╝ ███████╗██║  ██║╚██████╔╝    ███████╗
╚═╝  ╚═══╝╚═╝  ╚═══╝  ╚══════╝╚═╝  ╚═╝ ╚═════╝     ╚══════╝
                                                                                                    
";
        Console.WriteLine(cavalierniveau2);
    }
    public void niveau3()
    {
        string cavalierniveau3 = @"
███╗   ██╗██╗██╗   ██╗███████╗ █████╗ ██╗   ██╗    ██████╗ 
████╗  ██║██║██║   ██║██╔════╝██╔══██╗██║   ██║    ╚════██╗
██╔██╗ ██║██║██║   ██║█████╗  ███████║██║   ██║     █████╔╝
██║╚██╗██║██║╚██╗ ██╔╝██╔══╝  ██╔══██║██║   ██║     ╚═══██╗
██║ ╚████║██║ ╚████╔╝ ███████╗██║  ██║╚██████╔╝    ██████╔╝
╚═╝  ╚═══╝╚═╝  ╚═══╝  ╚══════╝╚═╝  ╚═╝ ╚═════╝     ╚═════╝ 
                                                                                                                                        
";
        Console.WriteLine(cavalierniveau3);
    }
    public void InitialiserPlateau()
    {
        for (int i = 0; i < Taille; i++)
            for (int j = 0; j < Taille; j++)
                Plateau[i, j] = ' ';
    }

    public void AfficherPlateau1(int cavalierX, int cavalierY)
    {
        Console.Clear();

        Plateau[cavalierX, cavalierY] = 'C';


        Console.Write("    ");
        for (int i = 0; i < Taille; i++)
            Console.Write("  " + (char)(65 + i) + " ");
        Console.WriteLine();

        for (int i = 0; i < Taille; i++)
        {
            Console.Write("    ");
            for (int j = 0; j < Taille; j++)
                Console.Write("╬═══");
            Console.WriteLine("╣");

            Console.Write("  " + (Taille - i) + " ");

            for (int j = 0; j < Taille; j++)
            {
                string position = $"{(char)(j + 'A')}{Taille - i}";

                if (VisitedPositions.Contains(position))
                {
                    Console.BackgroundColor = ConsoleColor.Red;
                    Console.Write("║ " + Plateau[i, j] + " ");
                    Console.ResetColor();
                }
                else
                {
                    bool mouvementValide = false;
                    for (int k = 0; k < 8; k++)
                    {
                        int nouvellePosX = cavalierX + DeplacementsCavalierX[k];
                        int nouvellePosY = cavalierY + DeplacementsCavalierY[k];

                        if (nouvellePosX == i && nouvellePosY == j && !VisitedPositions.Contains(position))
                        {
                            mouvementValide = true;
                            break;

                        }
                    }

                    if (mouvementValide)
                    {
                        Console.BackgroundColor = ConsoleColor.Blue;
                        Console.Write("║ " + Plateau[i, j] + " ");
                        Console.ResetColor();
                    }
                    else
                    {
                        Console.Write("║ " + Plateau[i, j] + " ");
                    }
                }
            }
            Console.WriteLine("║");
        }

        Console.Write("    ");
        for (int j = 0; j < Taille; j++)
            Console.Write("╬═══");
        Console.WriteLine("╣");

        Plateau[cavalierX, cavalierY] = ' ';

    }
    public void AfficherPlateau2(int cavalierX, int cavalierY, bool hideKnight = false)
    {
        Console.Clear();
        if (!hideKnight)
        {
            Plateau[cavalierX, cavalierY] = 'C';
        }

        Console.Write("    ");
        for (int i = 0; i < Taille; i++)
            Console.Write("  " + (char)(65 + i) + " ");
        Console.WriteLine();

        for (int i = 0; i < Taille; i++)
        {
            Console.Write("    ");
            for (int j = 0; j < Taille; j++)
                Console.Write("╬═══");
            Console.WriteLine("╣");

            Console.Write("  " + (Taille - i) + " ");

            for (int j = 0; j < Taille; j++)
            {
                string position = $"{(char)(j + 'A')}{Taille - i}";

                if (VisitedPositions.Contains(position))
                {
                    Console.BackgroundColor = ConsoleColor.Red;
                    Console.Write("║ " + Plateau[i, j] + " ");
                    Console.ResetColor();
                }
                else
                {
                    bool mouvementValide = false;
                    for (int k = 0; k < 8; k++)
                    {
                        int nouvellePosX = cavalierX + DeplacementsCavalierX[k];
                        int nouvellePosY = cavalierY + DeplacementsCavalierY[k];

                        if (nouvellePosX == i && nouvellePosY == j && !VisitedPositions.Contains(position))
                        {
                            mouvementValide = true;
                            break;

                        }
                    }

                    if (mouvementValide)
                    {
                        Console.Write("║ " + Plateau[i, j] + " ");
                        Console.ResetColor();
                    }
                    else
                    {
                        Console.Write("║ " + Plateau[i, j] + " ");
                    }
                }
            }
            Console.WriteLine("║");
        }

        Console.Write("    ");
        for (int j = 0; j < Taille; j++)
            Console.Write("╬═══");
        Console.WriteLine("╣");

        Plateau[cavalierX, cavalierY] = ' ';

    }
    public void AfficherPlateau3(int cavalierX, int cavalierY, bool hideKnight = false)
    {
        Console.Clear();
        if (!hideKnight)
        {
            Plateau[cavalierX, cavalierY] = 'C';
        }

        Console.Write("    ");
        for (int i = 0; i < Taille; i++)
            Console.Write("  " + (char)(65 + i) + " ");
        Console.WriteLine();

        for (int i = 0; i < Taille; i++)
        {
            Console.Write("    ");
            for (int j = 0; j < Taille; j++)
                Console.Write("╬═══");
            Console.WriteLine("╣");

            Console.Write("  " + (Taille - i) + " ");

            for (int j = 0; j < Taille; j++)
            {
                string position = $"{(char)(j + 'A')}{Taille - i}";

                if (VisitedPositions.Contains(position))
                {
                    Console.BackgroundColor = ConsoleColor.Red;
                    Console.Write("║ " + Plateau[i, j] + " ");
                    Console.ResetColor();
                }
                else
                {
                    bool mouvementValide = false;
                    for (int k = 0; k < 8; k++)
                    {
                        int nouvellePosX = cavalierX + DeplacementsCavalierX[k];
                        int nouvellePosY = cavalierY + DeplacementsCavalierY[k];

                        if (nouvellePosX == i && nouvellePosY == j && !VisitedPositions.Contains(position))
                        {
                            mouvementValide = true;
                            break;

                        }
                    }

                    if (mouvementValide)
                    {
                        Console.Write("║ " + Plateau[i, j] + " ");
                        Console.ResetColor();
                    }
                    else
                    {
                        Console.Write("║ " + Plateau[i, j] + " ");
                    }
                }
            }
            Console.WriteLine("║");
        }

        Console.Write("    ");
        for (int j = 0; j < Taille; j++)
            Console.Write("╬═══");
        Console.WriteLine("╣");

        Plateau[cavalierX, cavalierY] = ' ';

    }

    public void AfficherPlateau4(int cavalierX, int cavalierY, bool hideKnight = false)
    {
        Console.Clear();
        if (!hideKnight)
        {
            Plateau[cavalierX, cavalierY] = 'C';
        }

        Console.Write("    ");
        for (int i = 0; i < Taille; i++)
            Console.Write("  " + (char)(65 + i) + " ");
        Console.WriteLine();

        for (int i = 0; i < Taille; i++)
        {
            Console.Write("    ");
            for (int j = 0; j < Taille; j++)
                Console.Write("╬═══");
            Console.WriteLine("╣");

            Console.Write("  " + (Taille - i) + " ");

            for (int j = 0; j < Taille; j++)
            {
                string position = $"{(char)(j + 'A')}{Taille - i}";

                if (VisitedPositions.Contains(position))
                {
                    Console.Write("║ " + Plateau[i, j] + " ");
                }
                else
                {
                    bool mouvementValide = false;
                    for (int k = 0; k < 8; k++)
                    {
                        int nouvellePosX = cavalierX + DeplacementsCavalierX[k];
                        int nouvellePosY = cavalierY + DeplacementsCavalierY[k];

                        if (nouvellePosX == i && nouvellePosY == j && !VisitedPositions.Contains(position))
                        {
                            mouvementValide = true;
                            break;

                        }
                    }

                    if (mouvementValide)
                    {
                        Console.Write("║ " + Plateau[i, j] + " ");
                    }
                    else
                    {
                        Console.Write("║ " + Plateau[i, j] + " ");
                    }
                }
            }
            Console.WriteLine("║");
        }

        Console.Write("    ");
        for (int j = 0; j < Taille; j++)
            Console.Write("╬═══");
        Console.WriteLine("╣");

        Plateau[cavalierX, cavalierY] = ' ';

    }

    internal void RecordLastPosition(int x, int y)
    {
        this.LastX = x;
        this.LastY = y;
    }

    public string ObtenirPositionValidedif()
    {
        while (true)
        {
            string position = Console.ReadLine().ToUpper();

            if (position.Length == 2 &&
                position[0] >= 'A' && position[0] < 'A' + Taille &&
                position[1] >= '1' && position[1] <= (Taille + '0'))
            {
                return position;

            }
            else
            {
                Console.WriteLine("Position invalide. Entrez une position valide (ex: A1, B3, etc.).");
            }
        }
    }

    public void MarquerPositionVisitee(int x, int y)
    {

        string position = $"{(char)(y + 'A')}{Taille - x}";
        if (!VisitedPositions.Contains(position))
        {
            VisitedPositions.Add(position);
        }

    }

    public bool VerifierMouvement(int x, int y, int deplacementX, int deplacementY)
    {
        for (int i = 0; i < 8; i++)
        {
            int nouvelleX = x + DeplacementsCavalierX[i];
            int nouvelleY = y + DeplacementsCavalierY[i];

            if (nouvelleX == deplacementX && nouvelleY == deplacementY)
            {
                return true;
            }
        }
        return false;
    }
}
